# Copyright (c) The PyAMF Project.
# See LICENSE.txt for details.

"""
Unit tests for Remoting gateways.

@since: 0.1.0
"""
