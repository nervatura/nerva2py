#!/bin/sh
/usr/bin/python nwx.pyw
